-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 20, 2019 at 09:30 AM
-- Server version: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_eams`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

DROP TABLE IF EXISTS `tbl_attendance`;
CREATE TABLE IF NOT EXISTS `tbl_attendance` (
  `attendance_entry` int(11) NOT NULL AUTO_INCREMENT,
  `event_entry_id` varchar(20) NOT NULL,
  `student_assigned_to_list_id` varchar(11) NOT NULL,
  `community_labor_minutes` varchar(3) NOT NULL,
  `log_in_time` time DEFAULT NULL,
  `log_out_Time` time DEFAULT NULL,
  PRIMARY KEY (`attendance_entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_community_labor_summary`
--

DROP TABLE IF EXISTS `tbl_community_labor_summary`;
CREATE TABLE IF NOT EXISTS `tbl_community_labor_summary` (
  `summary_entry` int(11) NOT NULL AUTO_INCREMENT,
  `summary_title` varchar(25) NOT NULL,
  `list_id` int(11) NOT NULL,
  `event_one` varchar(20) DEFAULT NULL,
  `event_two` varchar(20) DEFAULT NULL,
  `event_three` varchar(20) DEFAULT NULL,
  `event_four` varchar(20) DEFAULT NULL,
  `event_five` varchar(20) DEFAULT NULL,
  `event_six` varchar(20) DEFAULT NULL,
  `event_seven` varchar(20) DEFAULT NULL,
  `event_eight` varchar(20) DEFAULT NULL,
  `event_nine` varchar(20) DEFAULT NULL,
  `event_ten` varchar(20) DEFAULT NULL,
  `event_eleven` varchar(20) DEFAULT NULL,
  `event_twelve` varchar(20) DEFAULT NULL,
  `event_thirteen` varchar(20) DEFAULT NULL,
  `event_fourteen` varchar(20) DEFAULT NULL,
  `event_fifteen` varchar(20) DEFAULT NULL,
  `activate` varchar(1) NOT NULL,
  PRIMARY KEY (`summary_entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

DROP TABLE IF EXISTS `tbl_event`;
CREATE TABLE IF NOT EXISTS `tbl_event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_title` varchar(120) NOT NULL,
  `event_description` varchar(120) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event_assessment`
--

DROP TABLE IF EXISTS `tbl_event_assessment`;
CREATE TABLE IF NOT EXISTS `tbl_event_assessment` (
  `event_assessment_entry` int(11) NOT NULL AUTO_INCREMENT,
  `attendance_entry_id` int(11) NOT NULL,
  `event_rating` int(1) NOT NULL,
  `event_remarks` varchar(250) NOT NULL,
  PRIMARY KEY (`event_assessment_entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event_entry`
--

DROP TABLE IF EXISTS `tbl_event_entry`;
CREATE TABLE IF NOT EXISTS `tbl_event_entry` (
  `event_entry_id` varchar(20) NOT NULL,
  `event_id` varchar(3) NOT NULL,
  `event_date` date NOT NULL,
  `event_entry_date_created` date NOT NULL,
  `session` varchar(9) NOT NULL,
  `school_year` varchar(9) NOT NULL,
  `semester` varchar(3) NOT NULL,
  `event_rating_enabled` varchar(3) NOT NULL,
  `event_status` varchar(8) NOT NULL,
  `penalty_full` int(4) NOT NULL,
  `penalty_half` int(4) NOT NULL,
  PRIMARY KEY (`event_entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

DROP TABLE IF EXISTS `tbl_student`;
CREATE TABLE IF NOT EXISTS `tbl_student` (
  `student_entry` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(11) NOT NULL,
  `student_first_name` varchar(60) NOT NULL,
  `student_last_name` varchar(60) NOT NULL,
  PRIMARY KEY (`student_entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_assigned_to_list`
--

DROP TABLE IF EXISTS `tbl_student_assigned_to_list`;
CREATE TABLE IF NOT EXISTS `tbl_student_assigned_to_list` (
  `student_assigned_to_list_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_entry_id` int(11) NOT NULL,
  `list_id` int(11) NOT NULL,
  PRIMARY KEY (`student_assigned_to_list_id`),
  KEY `student_entry_id` (`student_entry_id`,`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_list`
--

DROP TABLE IF EXISTS `tbl_student_list`;
CREATE TABLE IF NOT EXISTS `tbl_student_list` (
  `list_id` int(11) NOT NULL AUTO_INCREMENT,
  `list_title` varchar(100) NOT NULL,
  PRIMARY KEY (`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
